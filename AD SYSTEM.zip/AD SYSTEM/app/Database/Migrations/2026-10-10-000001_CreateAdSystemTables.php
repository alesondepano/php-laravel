<?php
namespace App\Database\Migrations;
use CodeIgniter\Database\Migration;
class CreateAdSystemTables extends Migration
{
    public function up(){
        $this->forge->addField(['id'=>['type'=>'INT','auto_increment'=>true],'title'=>['type'=>'VARCHAR','constraint'=>150],'status'=>['type'=>'VARCHAR','constraint'=>20,'default'=>'pending'],'task_date'=>['type'=>'DATE'],'created_at'=>['type'=>'DATETIME']]);$this->forge->addKey('id',true);$this->forge->createTable('tasks',true);
        $this->forge->addField(['id'=>['type'=>'INT','auto_increment'=>true],'full_name'=>['type'=>'VARCHAR','constraint'=>100],'email'=>['type'=>'VARCHAR','constraint'=>100],'phone'=>['type'=>'VARCHAR','constraint'=>20,'null'=>true],'created_at'=>['type'=>'DATETIME']]);$this->forge->addKey('id',true);$this->forge->addUniqueKey('email');$this->forge->createTable('customers',true);
        $this->forge->addField(['id'=>['type'=>'INT','auto_increment'=>true],'username'=>['type'=>'VARCHAR','constraint'=>50],'full_name'=>['type'=>'VARCHAR','constraint'=>100],'email'=>['type'=>'VARCHAR','constraint'=>100],'avatar'=>['type'=>'VARCHAR','constraint'=>255,'null'=>true],'created_at'=>['type'=>'DATETIME']]);$this->forge->addKey('id',true);$this->forge->addUniqueKey('username');$this->forge->addUniqueKey('email');$this->forge->createTable('users',true);
    }
    public function down(){ $this->forge->dropTable('tasks',true);$this->forge->dropTable('customers',true);$this->forge->dropTable('users',true); }
}
