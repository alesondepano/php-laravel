<?php
namespace App\Controllers;

use App\Models\CustomerModel;
use CodeIgniter\Exceptions\PageNotFoundException;

class Customers extends BaseController
{
    private function rules(?int $ignoreId = null): array
    {
        $unique = $ignoreId === null ? 'is_unique[customers.email]' : "is_unique[customers.email,id,{$ignoreId}]";
        return ['full_name' => 'required|max_length[100]', 'email' => "required|valid_email|max_length[100]|{$unique}", 'phone' => 'permit_empty|max_length[20]'];
    }

    private function posted(): array
    {
        return ['full_name' => trim((string)$this->request->getPost('full_name')), 'email' => trim((string)$this->request->getPost('email')), 'phone' => trim((string)$this->request->getPost('phone'))];
    }

    public function index(): string { $m = new CustomerModel(); $q = trim((string)$this->request->getGet('q')); if ($q !== '') $m->groupStart()->like('full_name', $q)->orLike('email', $q)->orLike('phone', $q)->groupEnd(); return view('customers/index', ['title' => 'Customers', 'customers' => $m->orderBy('id', 'DESC')->findAll(), 'search' => $q]); }
    public function newForm(array $customer = []): string { return view('customers/form', ['title' => 'New Customer', 'heading' => 'New Customer', 'customer' => $customer, 'action' => site_url('customers/create')]); }
    public function create() { $data = $this->posted(); if (!$this->validate($this->rules())) return $this->newForm($data); (new CustomerModel())->insert($data + ['created_at' => date('Y-m-d H:i:s')]); return redirect()->to(site_url('customers'))->with('success', 'Customer created successfully.'); }
    public function view(int $id): string { $row = (new CustomerModel())->find($id); if (!$row) throw PageNotFoundException::forPageNotFound(); return view('customers/view', ['title' => 'View Customer', 'customer' => $row]); }
    public function edit(int $id): string { $row = (new CustomerModel())->find($id); if (!$row) throw PageNotFoundException::forPageNotFound(); return view('customers/form', ['title' => 'Edit Customer', 'heading' => 'Edit Customer', 'customer' => $row, 'action' => site_url('customers/update/' . $id)]); }
    public function update(int $id) { $m = new CustomerModel(); $row = $m->find($id); if (!$row) throw PageNotFoundException::forPageNotFound(); $data = $this->posted(); if (!$this->validate($this->rules($id))) return view('customers/form', ['title' => 'Edit Customer', 'heading' => 'Edit Customer', 'customer' => $data + $row, 'action' => site_url('customers/update/' . $id)]); $m->update($id, $data); return redirect()->to(site_url('customers'))->with('success', 'Customer updated successfully.'); }
    public function delete(int $id) { $m = new CustomerModel(); if (!$m->find($id)) throw PageNotFoundException::forPageNotFound(); $m->delete($id); return redirect()->to(site_url('customers'))->with('success', 'Customer deleted successfully.'); }
}
