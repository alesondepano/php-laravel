<?php

namespace App\Controllers;

use App\Models\TaskModel;

class Tasks extends BaseController
{
    public function index(): string
    {
        $model = new TaskModel();
        $status = trim((string) $this->request->getGet('status'));
        $date = trim((string) $this->request->getGet('date'));
        if ($status !== '') $model->where('status', $status);
        if ($date !== '') $model->where('task_date', $date);
        return view('tasks/index', [
            'title' => 'Tasks',
            'tasks' => $model->orderBy('task_date', 'ASC')->orderBy('created_at', 'ASC')->findAll(),
            'status' => $status,
            'date' => $date,
        ]);
    }
}
