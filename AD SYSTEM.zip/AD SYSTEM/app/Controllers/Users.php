<?php
namespace App\Controllers;

use App\Models\UserModel;
use CodeIgniter\Exceptions\PageNotFoundException;

class Users extends BaseController
{
    private function rules(bool $avatar = false, ?int $ignoreId = null): array
    {
        $email = $ignoreId === null ? 'is_unique[users.email]' : "is_unique[users.email,id,{$ignoreId}]";
        $username = $ignoreId === null ? 'is_unique[users.username]' : "is_unique[users.username,id,{$ignoreId}]";
        $rules = ['username' => "required|max_length[50]|{$username}", 'full_name' => 'required|max_length[100]', 'email' => "permit_empty|valid_email|max_length[100]|{$email}"];
        if ($avatar) $rules['avatar'] = 'permit_empty|is_image[avatar]|mime_in[avatar,image/jpg,image/jpeg,image/png]|max_size[avatar,2048]';
        return $rules;
    }

    private function posted(): array { return ['username' => trim((string)$this->request->getPost('username')), 'full_name' => trim((string)$this->request->getPost('full_name')), 'email' => trim((string)$this->request->getPost('email'))]; }
    private function form(string $title, array $user, string $action): string { return view('users/form', ['title' => $title, 'heading' => $title, 'user' => $user, 'action' => $action]); }
    public function index(): string { $m = new UserModel(); $q = trim((string)$this->request->getGet('q')); if ($q !== '') $m->groupStart()->like('username', $q)->orLike('full_name', $q)->orLike('email', $q)->groupEnd(); return view('users/index', ['title' => 'Users', 'users' => $m->orderBy('id', 'DESC')->findAll(), 'search' => $q]); }
    public function newForm(array $user = []): string { return $this->form('New User', $user, site_url('users/create')); }
    public function create() { $data = $this->posted(); if (!$this->validate($this->rules())) return $this->newForm($data); (new UserModel())->insert($data + ['created_at' => date('Y-m-d H:i:s')]); return redirect()->to(site_url('users'))->with('success', 'User created successfully.'); }
    public function view(int $id): string { $user = (new UserModel())->find($id); if (!$user) throw PageNotFoundException::forPageNotFound(); return view('users/view', ['title' => 'View User', 'user' => $user]); }
    public function edit(int $id): string { $user = (new UserModel())->find($id); if (!$user) throw PageNotFoundException::forPageNotFound(); return $this->form('Edit User', $user, site_url('users/update/' . $id)); }
    public function update(int $id)
    {
        $m = new UserModel();
        $user = $m->find($id);
        if (!$user) throw PageNotFoundException::forPageNotFound();
        $data = $this->posted();
        if (!$this->validate($this->rules(true, $id))) return $this->form('Edit User', $data + $user, site_url('users/update/' . $id));

        $file = $this->request->getFile('avatar');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            $directory = FCPATH . 'uploads/avatars';
            if (!is_dir($directory)) mkdir($directory, 0755, true);
            $temporary = 'tmp_' . $file->getRandomName();
            $file->move($directory, $temporary);
            $filename = 'avatar_' . $file->getRandomName();
            service('image')->withFile($directory . '/' . $temporary)->fit(300, 300, 'center')->save($directory . '/' . $filename);
            unlink($directory . '/' . $temporary);
            if (!empty($user['avatar']) && is_file($directory . '/' . basename($user['avatar']))) unlink($directory . '/' . basename($user['avatar']));
            $data['avatar'] = $filename;
        }
        $m->update($id, $data);
        return redirect()->to(site_url('users'))->with('success', 'User updated successfully.');
    }

    public function delete(int $id)
    {
        $m = new UserModel();
        $user = $m->find($id);
        if (!$user) throw PageNotFoundException::forPageNotFound();
        if (!empty($user['avatar']) && is_file(FCPATH . 'uploads/avatars/' . basename($user['avatar']))) unlink(FCPATH . 'uploads/avatars/' . basename($user['avatar']));
        $m->delete($id);
        return redirect()->to(site_url('users'))->with('success', 'User deleted successfully.');
    }
}
