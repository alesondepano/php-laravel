<?php

namespace App\Controllers;

use App\Models\CustomerModel;
use App\Models\TaskModel;
use App\Models\UserModel;

class Home extends BaseController
{
    public function index(): string
    {
        $tasks = new TaskModel();
        return view('dashboard', [
            'title' => 'Welcome',
            'customerCount' => (new CustomerModel())->countAll(),
            'taskCount' => $tasks->countAll(),
            'userCount' => (new UserModel())->countAll(),
            'todayTasks' => $tasks->forToday(),
        ]);
    }
}
